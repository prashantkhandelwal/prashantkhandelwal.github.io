﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing.Imaging;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Captcha;

namespace Captcha.NET
{
    public partial class _Default : System.Web.UI.Page
    {
        public string CaptchaCode;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CaptchaImage cImage = new CaptchaImage(CaptchaImage.generateRandomCode(), 140, 40);
                cImage.Image.Save(Server.MapPath("~\\CaptchaImages\\" + Convert.ToString(Session["CaptchaCode"]) + ".jpg"), ImageFormat.Jpeg);
                CaptachaImage.ImageUrl = "~\\CaptchaImages\\" + Convert.ToString(Session["CaptchaCode"]) + ".jpg";
                cImage.Dispose();
            }
            CaptchaCode = Convert.ToString(Session["CaptchaCode"]);
        }

        protected void btn_Validate(object sender, EventArgs e)
        {
            if (CaptchaCode == txt_ccode.Text)
            {
                ClientScript.RegisterClientScriptBlock(typeof(Page), "ValidateMsg", "<script>alert('You entered Correct CAPTCHA Code!');</script>");
            }
            else
            {
                ClientScript.RegisterClientScriptBlock(typeof(Page), "ValidateMsg", "<script>alert('You entered INCORRECT CAPTCHA Code!');</script>");
            }
        }
    }
}
