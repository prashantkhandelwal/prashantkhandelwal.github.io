using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Google.GData.Photos;
using Google.GData.Client;
using System.IO;
using System.Net;

namespace PicasaAlbumDownloader
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Picasa Album Downloader!");
            Console.WriteLine("User Name: ");
            string UserName = Console.ReadLine();
            Console.WriteLine("Album To Download: ");
            string AlbumName = Console.ReadLine();
            DownAlbum(UserName, AlbumName);
        }

        private static void DownAlbum(string UserN, string AlbumN)
        {
            string fileName;
            Uri uriPath;
            WebClient HttpClient = new WebClient();

            //  Three important elements of PicasaWeb API are 
            //  PhotoQuery, PicasaService and PicasaFeed
            PhotoQuery query = new PhotoQuery();
            query.Uri = new Uri(PhotoQuery.CreatePicasaUri(UserN, AlbumN));
            PicasaService service = new PicasaService("PicasaAlbumDownloader");
            PicasaFeed feed = (PicasaFeed)service.Query(query);

            Directory.SetCurrentDirectory(Application.StartupPath+"\\Downloads");
            foreach (AtomEntry aentry in feed.Entries)
            {
                uriPath = new Uri(aentry.Content.Src.ToString());
                fileName = uriPath.LocalPath.Substring(uriPath.LocalPath.LastIndexOf('/') + 1);
                try
                {
                    Console.WriteLine("Downloading: " + fileName);
                    HttpClient.DownloadFile(aentry.Content.Src.ToString(), fileName);
                    //Console.WriteLine("Download Complete");
                }
                catch (WebException we)
                { 
                    Console.WriteLine(we.Message); 
                }
            }
            Console.WriteLine("Download Complete!");
        }
    }
}
