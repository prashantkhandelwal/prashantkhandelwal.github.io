﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Web.Services;
using System.Data.SqlServerCe;
using System.Data;
using System.Text;

namespace InfiniteScroll
{
    public partial class _Default : System.Web.UI.Page
    {
        static string conStr = "DataSource=" + AppDomain.CurrentDomain.BaseDirectory + "\\App_Data\\BlogEngine.sdf;Persist Security Info=True;";
        static SqlCeConnection con = new SqlCeConnection(conStr);
        static SqlCeDataAdapter da;
        static DataTable dt;
        static int RecordCount = 0, FirstCount = 10;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                init.InnerHtml = GetData();
            }
        }

        [WebMethod]
        public static string GetData()
        {
            RecordCount = RecordCount + 10;
            string Sql = "SELECT Title, DateCreated, Slug FROM be_Posts ORDER BY Title OFFSET " + FirstCount + " ROWS FETCH NEXT 10 ROWS ONLY";
            FirstCount = RecordCount;
            StringBuilder sb = new StringBuilder();
            dt = new DataTable();
            da = new SqlCeDataAdapter(Sql, con);
            con.Open();
            da.Fill(dt);

            DataView dv = dt.DefaultView;

            foreach (DataRowView row in dv)
            {
                sb.AppendFormat("<p>Post Title" + " <strong>" + row["Title"] + "</strong>");
                sb.AppendFormat("<p>Post Date" + " <strong>" + row["DateCreated"] + "</strong>");
                sb.AppendFormat("<p>Slug" + " <strong>" + row["Slug"] + "</strong>");
                sb.AppendFormat("<hr/>");
            }

            sb.AppendFormat("<divstyle='height:15px;'></div>");
            con.Close();
            return sb.ToString();
        }
    }
}
