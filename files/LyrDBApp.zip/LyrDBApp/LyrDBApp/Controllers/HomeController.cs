﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using System.IO;


namespace LyrDBApp.Controllers
{
    public class HomeController : Controller
    {

        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to LyrDB App!";
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult GetLyrics(string ArtistName, string SongName)
        {
            string response = string.Empty;
            string LyrURL = string.Empty;
            string url = "http://webservices.lyrdb.com/lookup.php?q=" + ArtistName + "|" + SongName + "&for=match";
            WebResponse wResp = (WebRequest.Create(url) as HttpWebRequest).GetResponse();
            using (StreamReader sReader = new StreamReader(wResp.GetResponseStream()))
            {
                response = sReader.ReadToEnd();
            }

            if (response == "")
            {
                response = "No Lyrics found on LyrDB for " + SongName + " by " + ArtistName;
                goto Output;
            }

            string[] lyrID = response.Split('\\');

            response = "";

            LyrURL = "http://webservices.lyrdb.com/getlyr.php?q=" + lyrID[0]+"&callback=?";

            Output:

            return Json(new
            {
                success = true,
                Lyrics = LyrURL
            });
        }
    }
}
