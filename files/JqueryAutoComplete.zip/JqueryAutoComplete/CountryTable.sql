Create table Country
(
	ID int identity(1,1) primary key not null, 
	Country_Name varchar(50),
	EU_Country bit,
	Country_Alpha_Code varchar(10),
	Country_Cur_Code_Alpha varchar(10),
	Country_Cur_Name varchar(50)
)