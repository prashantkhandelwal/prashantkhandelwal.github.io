﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;

namespace JqueryAutoComplete
{
    public partial class About : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        SqlCommand cmd;
        SqlDataReader dr;

        private string countryName()
        {

            StringBuilder sb = new StringBuilder();
            cmd = new SqlCommand("Select country_name from M_Country where carrier_id = 6 order by country_name", con);
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                sb.Append(Convert.ToString(dr[0] + "|"));
            }

            return Convert.ToString(sb);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string ListCountries = countryName();
        }
    }
}
