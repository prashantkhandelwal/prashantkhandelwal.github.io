﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Linq;
using JqueryAutoComplete.DBModel;

namespace JqueryAutoComplete
{
    public partial class AutocompleteLINQ : System.Web.UI.Page
    {
        DeveloperDBEntities db = new DeveloperDBEntities();
        public IQueryable<Country> countries;
        public string Listcountries;

        protected void Page_Load(object sender, EventArgs e)
        {
            countries = from c in db.Countries select c;
            foreach (Country cobj in countries)
            {
                Listcountries += cobj.Country_Name + "|";
            }
        }
    }
}