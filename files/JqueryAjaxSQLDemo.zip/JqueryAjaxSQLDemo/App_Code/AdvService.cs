﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

/// <summary>
/// Summary description for AdvService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 

[System.Web.Script.Services.ScriptService]
public class AdvService : System.Web.Services.WebService
{

    #region SQLObjects
    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    #endregion

    public AdvService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string GetCtcDetails(int ID)
    {
        //Comment the below line if don't want to wait
        System.Threading.Thread.Sleep(2000);

        string Details = string.Empty;
        
        try
        {
            string ConString = ConfigurationSettings.AppSettings["ConnectionString"];
            con = new SqlConnection(ConString);
            cmd = new SqlCommand("SELECT FirstName, LastName, EmailAddress FROM Person.Contact WHERE ContactID = @CID", con);
            cmd.Parameters.Add("@CID", SqlDbType.Int, 4).Value = ID;
            con.Open();
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Details = "<table><tr><td>" + dr[0].ToString() + "</td></tr><tr><td>" + dr[1].ToString() + "</td></tr><tr><td>" + dr[2].ToString() + "</td></tr></table>";
            }
           
        }
        catch (Exception x)
        {
            //Uncomment the below line if you wish to see the exception
            //return Details + x.ToString();
        }
        return Details;
    }
}

