﻿#region Information
//Project Name: Word Demo (Automation)
//Author: Prashant Khandelwal  
//Date Created: 02.01.2009
//Last Modified: 07.01.2009
#endregion

#region Namespaces
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using Microsoft.Office;
using Word = Microsoft.Office.Interop.Word;
#endregion

namespace WordDemo
{
    public partial class frm_main : Form
    {
        int iTotalFields = 0;

        public frm_main()
        {
            InitializeComponent();
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            Object oMissing = System.Reflection.Missing.Value;

            Object oTrue = true;
            Object oFalse = false;

            Word.Application oWord = new Word.Application();
            Word.Document oWordDoc = new Word.Document();


            oWord.Visible = true;

            Object oTemplatePath = System.Windows.Forms.Application.StartupPath+"\\Report.dot";

            oWordDoc = oWord.Documents.Add(ref oTemplatePath, ref oMissing, ref oMissing, ref oMissing);

            foreach (Word.Field myMergeField in oWordDoc.Fields)
            {

                iTotalFields++;
                Word.Range rngFieldCode = myMergeField.Code;
                String fieldText = rngFieldCode.Text;

                if (fieldText.StartsWith(" MERGEFIELD"))
                {

                    Int32 endMerge = fieldText.IndexOf("\\");
                    Int32 fieldNameLength = fieldText.Length - endMerge;
                    String fieldName = fieldText.Substring(11, endMerge - 11);

                    fieldName = fieldName.Trim();

                    if (fieldName == "Name")
                    {
                        myMergeField.Select();
                        oWord.Selection.TypeText(txt_name.Text);
                    }

                    if (fieldName == "Address")
                    {
                        myMergeField.Select();
                        oWord.Selection.TypeText(txt_address.Text);
                    }

                    if (fieldName == "Age")
                    {
                        myMergeField.Select();
                        oWord.Selection.TypeText(num_age.Text);
                    }

                    if (fieldName == "EAddress")
                    {
                        myMergeField.Select();
                        oWord.Selection.TypeText(txt_email.Text);
                    }

                    if (fieldName == "Company")
                    {
                        myMergeField.Select();
                        oWord.Selection.TypeText(txt_company.Text);
                    }

                    if (fieldName == "TelNo")
                    {
                        myMergeField.Select();
                        oWord.Selection.TypeText(txt_tel.Text);
                    }

                    if (fieldName == "ODetails")
                    {
                        myMergeField.Select();
                        oWord.Selection.TypeText(txt_odetails.Text);
                    }
                }
            }
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
