-- enable CLR
EXEC sp_configure @configname = 'clr enabled', @configvalue = 1
RECONFIGURE WITH OVERRIDE
GO

--Set database trustworthy ON (Necessary)
Alter Database DeveloperDB Set Trustworthy ON


-- create Assembly
-- DROP ASSEMBLY IPTracker
CREATE ASSEMBLY IPTracker from 'C:\IPInfo.dll'  
WITH PERMISSION_SET = EXTERNAL_ACCESS
GO

-- create sproc
-- DROP PROC TrackIP
CREATE PROC TrackIP(@IP as nvarchar(50))
AS
	-- [Assembly Name].[Class Name].[CLR function Name]
	EXTERNAL NAME IPTracker.StoredProcedures.GetIPInfo
GO



EXEC TrackIP '74.50.116.130'


create table IPTrack
(
	IPAddress nvarchar(20),
	LocationCode nvarchar(10),
FIPS104 nvarchar (10),
ISO2 nvarchar(5),
ISO3 nvarchar(5),
ISON nvarchar(5),
Internet nvarchar(10),
CountryID nvarchar(10),
Country nvarchar(20),
RegionID nvarchar(5),
Region nvarchar(15),
RegionCode nvarchar(10),
Admn1Code nvarchar(10),
CityID nvarchar(10),
City nvarchar(20),
Latitude nvarchar(30),
Longitude nvarchar(30),
TimeZone nvarchar(10),
Certainty nvarchar(5)
)

select * from IPTrack