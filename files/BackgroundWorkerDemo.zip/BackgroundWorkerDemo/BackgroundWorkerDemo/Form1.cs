﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;
using System.Threading;


namespace BackgroundWorkerDemo
{
    public partial class Form1 : Form
    {
        #region SQL Vars
        SqlConnection con = new SqlConnection("Data source=mx;initial catalog=AdventureWorks;user id=sa;password=pass#word1");
        SqlCommand cmd;
        SqlDataReader dr;
        #endregion

        public Form1()
        {
            InitializeComponent();
        }

        #region BGW_Database Operation

        private void btn_start_Click(object sender, EventArgs e)
        {
            //Starts the backgroundworker process asynchronously
            bgw.RunWorkerAsync();
            btn_start.Enabled = false;
        }

        //Background worker DoWork method. Here we will perform our heavy duty tasks.
        //I have used a simple datareader object to traverse all the rows in the table. 
        //The table has around 19K rows.
        private void bgw_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                int i = 0;
                cmd = new SqlCommand("SELECT * FROM Person.Contact", con);
                con.Open();
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    i = i + 1;
                    //report to the backgroungworker progreechanged event of the background worker class
                    bgw.ReportProgress(i);
                    //Thread to slow down the process.
                    Thread.Sleep(1);
                    //Called and check if the cancellation of the operation is pending. If returned true
                    //DoWorkEventArgs object cancels the operation.
                    if (bgw.CancellationPending)
                    {
                        e.Cancel = true;
                        return;
                    }
                }
            }
            catch (Exception x)
            {
                MessageBox.Show("An error occured while performing operation" + x, "BackGroundWorker Demo Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
            }
        }

        private void bgw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                MessageBox.Show("Operation Cancelled");
                btn_start.Enabled = true;
            }
            else
            {
                MessageBox.Show("Operation Completed");
                btn_start.Enabled = true;
            }
        }

        private void bgw_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //Report porogress bar change
            progress.Value = e.ProgressPercentage;
        }

        //To cancel async operation
        private void btn_cancel_Click(object sender, EventArgs e)
        {
            //To cancel the asynchronous operation
            bgw.CancelAsync();

            progress.Value = 0;
            btn_start.Enabled = true;
        }
        #endregion
    }
}
