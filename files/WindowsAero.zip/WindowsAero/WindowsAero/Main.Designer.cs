﻿namespace WindowsAero
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_normal = new System.Windows.Forms.Button();
            this.btn_aero = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_normal
            // 
            this.btn_normal.Location = new System.Drawing.Point(12, 12);
            this.btn_normal.Name = "btn_normal";
            this.btn_normal.Size = new System.Drawing.Size(114, 23);
            this.btn_normal.TabIndex = 0;
            this.btn_normal.Text = "Normal Form";
            this.btn_normal.UseVisualStyleBackColor = true;
            this.btn_normal.Click += new System.EventHandler(this.btn_normal_Click);
            // 
            // btn_aero
            // 
            this.btn_aero.Location = new System.Drawing.Point(204, 12);
            this.btn_aero.Name = "btn_aero";
            this.btn_aero.Size = new System.Drawing.Size(114, 23);
            this.btn_aero.TabIndex = 1;
            this.btn_aero.Text = "Aero Enabled Form";
            this.btn_aero.UseVisualStyleBackColor = true;
            this.btn_aero.Click += new System.EventHandler(this.btn_aero_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(367, 51);
            this.Controls.Add(this.btn_aero);
            this.Controls.Add(this.btn_normal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main";
            this.Text = "Windows Aero";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_normal;
        private System.Windows.Forms.Button btn_aero;
    }
}

