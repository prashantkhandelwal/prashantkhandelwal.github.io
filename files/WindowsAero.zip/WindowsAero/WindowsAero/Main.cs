﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsAero
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void btn_normal_Click(object sender, EventArgs e)
        {
            NormalForm nForm = new NormalForm();
            nForm.Show();
        }

        private void btn_aero_Click(object sender, EventArgs e)
        {
            AeroForm aForm = new AeroForm();
            aForm.Show();
        }
    }
}
