using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;  //Use for DLL import attribute

namespace docprntpdf
{
    public partial class Form1 : Form
    {
        [DllImport("Winspool.drv")]
        private static extern bool SetDefaultPrinter(string printerName);   //Set default printer to the one available with your system or network.

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SetDefaultPrinter("Adobe PDF");    //Set the default printer. I have set it as my Adobe PDF printer
            
            
            
            Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.Application();

 

            object fileName = @"d:\cv_prashant.doc";    //specify the name of the file to print

            object confirmConversions = Type.Missing;

            object readOnly = true;

            object addToRecentFiles = Type.Missing;

            object passwordDoc = Type.Missing;

            object passwordTemplate = Type.Missing;

            object revert = Type.Missing;

            object writepwdoc = Type.Missing;

            object writepwTemplate = Type.Missing;

            object format = Type.Missing;

            object encoding = Type.Missing;

            object visible = Type.Missing;

            object openRepair = Type.Missing;

            object docDirection = Type.Missing;

            object notEncoding = Type.Missing;

            object xmlTransform = Type.Missing;

            object missing = System.Reflection.Missing.Value;

 

            Microsoft.Office.Interop.Word.Document doc = wordApp.Documents.Open(

                ref fileName, ref confirmConversions, ref readOnly, ref addToRecentFiles,

                ref passwordDoc, ref passwordTemplate, ref revert, ref writepwdoc,

                ref writepwTemplate, ref format, ref encoding, ref visible, ref openRepair,

                ref docDirection, ref notEncoding, ref xmlTransform);

 

            //wordApp.Visible = true;  //Un-comment, if you want to show word application to be visible while printing document.


	    // Check below for more settings

            object copies = "1";
            object pages = "";
            object range = Microsoft.Office.Interop.Word.WdPrintOutRange.wdPrintAllDocument;
            object items = Microsoft.Office.Interop.Word.WdPrintOutItem.wdPrintDocumentContent;
            object pageType = Microsoft.Office.Interop.Word.WdPrintOutPages.wdPrintAllPages;
            object oTrue = true;
            object oFalse = false;


            doc.PrintOut(
    ref oTrue, ref oFalse, ref range, ref missing, ref missing, ref missing,
    ref items, ref copies, ref pages, ref pageType, ref oFalse, ref oTrue,
    ref missing, ref oFalse, ref missing, ref missing, ref missing, ref missing);

            //After set and successfullt print of the document, you might need to change the default printer to the one previouly selected one.

//            SetDefaultPrinter("");  //Set your default printer name here




           //wordApp.Quit(ref missingValue,ref M
           //doc.PrintPreview();              //shows the print-preview of the file according to the default printer set.

        }

        }
    }