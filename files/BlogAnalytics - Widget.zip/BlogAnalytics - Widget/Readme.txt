To install the widget:

1. Copy and paste all the DLLs from the bin folder to your BlogEngine's bin folder.
2. Copy BlogAnalytics folder and place it under widgets folder in your BlogEngine's setup.

This is it. You will now have to modify he settings so you can have your Google Analytics data on your BlogEngine...

To know more about widget read here: http://midnightprogrammer.net/post/Blog-Analytics-Widget-For-BlogEngineNET-Powered-By-Google-Analytics.aspx


"Just because you have less hits.....don't stop blogging"

