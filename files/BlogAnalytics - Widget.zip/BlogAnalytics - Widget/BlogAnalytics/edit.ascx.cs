﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using App_Code.Controls;
using BlogEngine.Core;
using Resources;

public partial class widgets_GAnalytics_edit : WidgetEditBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            var settings = GetSettings();
            if (settings.ContainsKey("UserName"))
                txtUsrName.Text = settings["UserName"];

            if (settings.ContainsKey("Password"))
                txtPasswd.Text = settings["Password"];

            if (settings.ContainsKey("FromDate"))
                FromDate.Text = settings["FromDate"];

            if (settings.ContainsKey("ToDate"))
                ToDate.Text = settings["ToDate"];

            if (settings.ContainsKey("CurrentToDate"))
                chkCurrentToDate.Checked = Convert.ToBoolean(settings["CurrentToDate"]);

            if (settings.ContainsKey("UseCurrentDate"))
                chkCurrentDate.Checked = Convert.ToBoolean(settings["UseCurrentDate"]);

            if (settings.ContainsKey("Vis_TotalPageViews"))
                STotalPageViews.Checked = Convert.ToBoolean(settings["Vis_TotalPageViews"]);

            if (settings.ContainsKey("Vis_TotalVisits"))
                STotalVisits.Checked = Convert.ToBoolean(settings["Vis_TotalVisits"]);

            if (settings.ContainsKey("Vis_Totalvisitors"))
                STotalVisitors.Checked = Convert.ToBoolean(settings["Vis_Totalvisitors"]);
        }
    }
    public override void Save()
    {
        var settings = GetSettings();
        settings["UserName"] = txtUsrName.Text;
        settings["Password"] = txtPasswd.Text;
        settings["FromDate"] = FromDate.Text;
        settings["ToDate"] = ToDate.Text;
        settings["CurrentToDate"] = chkCurrentToDate.Checked.ToString();
        settings["UseCurrentDate"] = chkCurrentDate.Checked.ToString();

        settings["Vis_TotalPageViews"] = STotalPageViews.Checked.ToString();
        settings["Vis_TotalVisits"] = STotalVisits.Checked.ToString();
        settings["Vis_Totalvisitors"] = STotalVisitors.Checked.ToString();

        SaveSettings(settings);
    }
}