﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Google.GData.Analytics;
using Google.GData.Extensions;
using App_Code.Controls;
using BlogEngine.Core;
using Resources;

public partial class widgets_GAnalytics_widget : WidgetBase
{
    const string dataFeedUrl = "https://www.google.com/analytics/feeds/data";

    Int32 Visits = 0;
    Int32 PageViewVisit = 0;

    int TotalVisitors = 0;
    int TotalPageViews = 0;
    int TotalVisits = 0;

    string userName = string.Empty;
    string passWord = string.Empty;
    string FromDate = DateTime.Now.ToString("yyyy-MM-dd");
    string ToDate = DateTime.Now.ToString("yyyy-MM-dd");

    private void GetStats()
    {
        var settings = GetSettings();
        AccountQuery query = new AccountQuery();
        AnalyticsService service = new AnalyticsService("BlogEngineWidget");
        if (!string.IsNullOrEmpty(userName))
        {
            service.setUserCredentials(userName, passWord);
        }
        string str = "";
        AccountFeed accountFeed = service.Query(query);
        foreach (AccountEntry entry in accountFeed.Entries)
        {
            str = entry.ProfileId.Value;
        }

        DataQuery Dataquery = new DataQuery(dataFeedUrl);

        if (Convert.ToBoolean(settings["Vis_TotalPageViews"]) == true)
        {
            // total pageviews of site
            Dataquery.Ids = str;
            Dataquery.Metrics = "ga:pageviews";//visitors
            Dataquery.Sort = "ga:pageviews";
            Dataquery.GAStartDate = FromDate;
            Dataquery.GAEndDate = ToDate;

            DataFeed dataFeedpageviews = service.Query(Dataquery);
            foreach (DataEntry entry in dataFeedpageviews.Entries)
            {
                string st = entry.Title.Text;
                string ss = entry.Metrics[0].Value;
                PageViewVisit = Int32.Parse(ss);
                TotalPageViews = Convert.ToInt32(ss);
            }
        }

        // total visits
        if (Convert.ToBoolean(settings["Vis_TotalVisits"]) == true)
        {
            Dataquery.Ids = str;
            Dataquery.Metrics = "ga:visits";//visitors
            Dataquery.Sort = "ga:visits";
            Dataquery.GAStartDate = FromDate;
            Dataquery.GAEndDate = ToDate;
            Dataquery.StartIndex = 1;
            DataFeed dataFeedVisits = service.Query(Dataquery);
            foreach (DataEntry entry in dataFeedVisits.Entries)
            {
                string st = entry.Title.Text;
                string ss = entry.Metrics[0].Value;
                Visits = Int32.Parse(ss);
                TotalVisits = Convert.ToInt32(ss);

            }
        }


        // total visitors of site
        if (Convert.ToBoolean(settings["Vis_Totalvisitors"]) == true)
        {
            Dataquery.Ids = str;
            Dataquery.Metrics = "ga:visitors";//visitors
            Dataquery.Sort = "ga:visitors";
            Dataquery.GAStartDate = FromDate;
            Dataquery.GAEndDate = ToDate;
            Dataquery.StartIndex = 1;

            DataFeed Feedvisitors = service.Query(Dataquery);
            foreach (DataEntry entry in Feedvisitors.Entries)
            {
                string st = entry.Title.Text;
                string ss = entry.Metrics[0].Value;
                PageViewVisit = Int32.Parse(ss);
                TotalVisitors = Convert.ToInt32(ss);

            }
        }
    }

    public override string Name
    {
        get { return "BlogAnalytics"; }
    }

    public override bool IsEditable
    {
        get { return true; }
    }

    public override void LoadWidget()
    {
        var settings = GetSettings();
        userName = string.Empty;
        passWord = string.Empty;
        userName = settings["UserName"];
        passWord = settings["Password"];
        FromDate = settings["FromDate"];
        ToDate = settings["ToDate"];

        //Thits.Attributes.Add("visible", "false");

        if (Convert.ToBoolean(settings["UseCurrentDate"]) == true)
        {
            FromDate = DateTime.Now.ToString("yyyy-MM-dd");
            ToDate = DateTime.Now.ToString("yyyy-MM-dd");

            //Thits.Attributes.Add("visible", "true");
        }

        if (Convert.ToBoolean(settings["CurrentToDate"]) == true)
        {
            ToDate = DateTime.Now.ToString("yyyy-MM-dd");
        }

        if (userName != null)
        {
            GetStats();
        }

        if (Convert.ToBoolean(settings["Vis_TotalPageViews"]) == true && (Convert.ToBoolean(settings["Vis_TotalVisits"]) == true) && (Convert.ToBoolean(settings["Vis_Totalvisitors"]) == true))
        {
            //Thits.Attributes.Add("visible", "false");
                
            Analyticdata.Text = "Total Page Views: " + Convert.ToString(TotalPageViews) + "<br />" + "Total Visits: " + Convert.ToString(TotalVisits) + "<br />" + "Total Visitors: " + Convert.ToString(TotalVisitors);
        }

        if (Convert.ToBoolean(settings["Vis_TotalPageViews"]) == true && (Convert.ToBoolean(settings["Vis_TotalVisits"]) == false) && (Convert.ToBoolean(settings["Vis_Totalvisitors"]) == false))
        {
            Analyticdata.Text = "Total Page Views: " + Convert.ToString(TotalPageViews);
        }

        if (Convert.ToBoolean(settings["Vis_TotalPageViews"]) == false && (Convert.ToBoolean(settings["Vis_TotalVisits"]) == true) && (Convert.ToBoolean(settings["Vis_Totalvisitors"]) == true))
        {
            Analyticdata.Text = "Total Visits: " + Convert.ToString(TotalVisits) + "<br />" + "Total Visitors: " + Convert.ToString(TotalVisitors);
        }

        if (Convert.ToBoolean(settings["Vis_TotalPageViews"]) == false && (Convert.ToBoolean(settings["Vis_TotalVisits"]) == false) && (Convert.ToBoolean(settings["Vis_Totalvisitors"]) == true))
        {
            Analyticdata.Text = "Total Visitors: " + Convert.ToString(TotalVisitors);
        }

        if (Convert.ToBoolean(settings["Vis_TotalPageViews"]) == false && (Convert.ToBoolean(settings["Vis_TotalVisits"]) == true) && (Convert.ToBoolean(settings["Vis_Totalvisitors"]) == false))
        {
            Analyticdata.Text = "Total Visits: " + Convert.ToString(TotalVisits);
        }
        if (Convert.ToBoolean(settings["Vis_TotalPageViews"]) == true && (Convert.ToBoolean(settings["Vis_TotalVisits"]) == false) && (Convert.ToBoolean(settings["Vis_Totalvisitors"]) == true))
        {
            Analyticdata.Text = "Total Page Views: " + Convert.ToString(TotalPageViews) + "<br />" + "Total Visitors: " + Convert.ToString(TotalVisitors);
        }

    }
}