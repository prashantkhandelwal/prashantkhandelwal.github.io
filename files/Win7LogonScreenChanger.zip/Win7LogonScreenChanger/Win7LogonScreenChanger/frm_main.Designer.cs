﻿namespace Win7LogonScreenChanger
{
    partial class frm_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_main));
            this.ofd = new System.Windows.Forms.OpenFileDialog();
            this.logonscreen = new System.Windows.Forms.PictureBox();
            this.btn_browse = new System.Windows.Forms.Button();
            this.btn_changeLogon = new System.Windows.Forms.Button();
            this.lbl_note = new System.Windows.Forms.Label();
            this.lbl_author = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.logonscreen)).BeginInit();
            this.SuspendLayout();
            // 
            // ofd
            // 
            this.ofd.Filter = "JPE Files|*.jpg";
            this.ofd.InitialDirectory = "Desktop";
            this.ofd.RestoreDirectory = true;
            this.ofd.Title = "Select Image";
            // 
            // logonscreen
            // 
            this.logonscreen.Location = new System.Drawing.Point(14, 14);
            this.logonscreen.Name = "logonscreen";
            this.logonscreen.Size = new System.Drawing.Size(265, 194);
            this.logonscreen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logonscreen.TabIndex = 1;
            this.logonscreen.TabStop = false;
            // 
            // btn_browse
            // 
            this.btn_browse.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_browse.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_browse.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_browse.Location = new System.Drawing.Point(286, 14);
            this.btn_browse.Name = "btn_browse";
            this.btn_browse.Size = new System.Drawing.Size(129, 44);
            this.btn_browse.TabIndex = 2;
            this.btn_browse.Text = "Browse";
            this.btn_browse.UseVisualStyleBackColor = true;
            this.btn_browse.Click += new System.EventHandler(this.btn_browse_Click);
            // 
            // btn_changeLogon
            // 
            this.btn_changeLogon.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_changeLogon.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_changeLogon.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_changeLogon.Location = new System.Drawing.Point(286, 65);
            this.btn_changeLogon.Name = "btn_changeLogon";
            this.btn_changeLogon.Size = new System.Drawing.Size(129, 44);
            this.btn_changeLogon.TabIndex = 3;
            this.btn_changeLogon.Text = "Change Logon Screen";
            this.btn_changeLogon.UseVisualStyleBackColor = true;
            this.btn_changeLogon.Click += new System.EventHandler(this.btn_changeLogon_Click);
            // 
            // lbl_note
            // 
            this.lbl_note.AutoSize = true;
            this.lbl_note.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_note.Location = new System.Drawing.Point(285, 175);
            this.lbl_note.Name = "lbl_note";
            this.lbl_note.Size = new System.Drawing.Size(105, 15);
            this.lbl_note.TabIndex = 4;
            this.lbl_note.Text = "© Copyright 2010";
            // 
            // lbl_author
            // 
            this.lbl_author.AutoSize = true;
            this.lbl_author.Location = new System.Drawing.Point(290, 193);
            this.lbl_author.Name = "lbl_author";
            this.lbl_author.Size = new System.Drawing.Size(125, 15);
            this.lbl_author.TabIndex = 5;
            this.lbl_author.TabStop = true;
            this.lbl_author.Text = "Prashant Khandelwal";
            this.lbl_author.Click += new System.EventHandler(this.lbl_author_Click);
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 223);
            this.Controls.Add(this.lbl_author);
            this.Controls.Add(this.lbl_note);
            this.Controls.Add(this.btn_changeLogon);
            this.Controls.Add(this.btn_browse);
            this.Controls.Add(this.logonscreen);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frm_main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Win 7 Login Screen Changer";
            this.Load += new System.EventHandler(this.frm_main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logonscreen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog ofd;
        private System.Windows.Forms.PictureBox logonscreen;
        private System.Windows.Forms.Button btn_browse;
        private System.Windows.Forms.Button btn_changeLogon;
        private System.Windows.Forms.Label lbl_note;
        private System.Windows.Forms.LinkLabel lbl_author;
    }
}

