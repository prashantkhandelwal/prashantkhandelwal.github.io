﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.IO;

using System.Diagnostics;

namespace Win7LogonScreenChanger
{
    public partial class frm_main : Form
    {
        private string BkImgPath = Environment.SystemDirectory.ToString() + "\\oobe";
        private string LogonImage = "";
        FileInfo FI;
        
        public frm_main()
        {
            InitializeComponent();
        }

        private void CreateFolders()
        {
            try
            {
                Directory.CreateDirectory(BkImgPath + "\\info");
                Directory.CreateDirectory(BkImgPath + "\\info\\backgrounds");
            }
            catch { }
        }

        private void btn_browse_Click(object sender, EventArgs e)
        {
            DialogResult result = ofd.ShowDialog();
            if (result == DialogResult.OK)
            {
                logonscreen.ImageLocation = ofd.FileName.ToString();
                LogonImage = ofd.FileName.ToString();
                
                FI = new FileInfo(LogonImage);
                if(FI.Length>262144)
                {
                    MessageBox.Show("Image cannot be larger than 256 KB","Win 7 Login Screen Changer",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    return;
                }
                btn_changeLogon.Enabled = true;
            }
        }

        private void frm_main_Load(object sender, EventArgs e)
        {
            if (Directory.Exists(BkImgPath + "\\info\\backgrounds"))
            {
                logonscreen.ImageLocation = BkImgPath + "\\info\\backgrounds\\backgroundDefault.jpg";
            }

            if (!Directory.Exists(BkImgPath + "\\info\\backgrounds"))
            {
                logonscreen.ImageLocation = BkImgPath + "\\background.bmp";
            }
            btn_changeLogon.Enabled = false;
        }

        private void btn_changeLogon_Click(object sender, EventArgs e)
        {
            CreateFolders();
            try
            {
                RegistryKey regkey = Registry.LocalMachine;
                regkey = regkey.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Authentication\\LogonUI\\Background");
                string obj = Convert.ToString(regkey.GetValue("OEMBackground"));
                if (obj.Equals("0"))
                {
                    regkey.SetValue("OEMBackground", 1);
                    regkey.Close();
                }
            }
            catch { }

            try
            {
                File.Delete(BkImgPath + "\\info\\backgrounds\\backgroundDefault.jpg");
                File.Copy(LogonImage, BkImgPath + "\\info\\backgrounds\\backgroundDefault.jpg");
            }
            catch { }

            MessageBox.Show("Logon Screen Changed!", "Win 7 Login Screen Changer", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btn_changeLogon.Enabled = false;
        }

        private void lbl_author_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("http://www.midnightprogrammer.net");
            }
            catch { }
        }
    }
}
