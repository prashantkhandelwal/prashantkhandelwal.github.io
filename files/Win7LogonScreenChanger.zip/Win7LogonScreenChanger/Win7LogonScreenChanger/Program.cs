﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Win7LogonScreenChanger
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            if (!OS.OSInfo.Name.Equals("Windows Vista"))
            {
                MessageBox.Show("Your Operating System is Not Supported", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (OS.OSInfo.Name == "Windows Vista")
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frm_main());
            }
        }
    }
}
