﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DotNetOpenAuth.OpenId.RelyingParty;
using DotNetOpenAuth.OpenId.Extensions.SimpleRegistration;

namespace DOTNETOAUTH
{
    public partial class _Default : System.Web.UI.Page
    {
        IAuthenticationResponse OResponse;

        public string UserName = string.Empty;
        public string Gender = "No Gender Specified";
        public string Country = string.Empty;
        public string Nick = string.Empty;
        public string Bday = string.Empty;
   
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                OResponse = (IAuthenticationResponse)Session["OpenID"];
                var details = OResponse.GetExtension<ClaimsResponse>();

                UserName = details.FullName;
                //email = details.Email;
                Gender = details.Gender.ToString();
                Country = details.Country;
                Nick = details.Nickname;
                Bday = details.BirthDate.ToString();
            }
            catch { }
        }
    }
}
