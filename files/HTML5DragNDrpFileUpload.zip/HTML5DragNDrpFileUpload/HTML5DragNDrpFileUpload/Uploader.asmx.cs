﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.IO;
using System.Web.Script.Serialization;
using System.Web.Script.Services;


namespace HTML5DragNDrpFileUpload
{
    /// <summary>
    /// Summary description for Uploader
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class Uploader : System.Web.Services.WebService
    {

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Upload()
        {
            HttpContext postedContext = HttpContext.Current;
            HttpPostedFile file = postedContext.Request.Files[0];
            string name = file.FileName;
            byte[] binaryWriteArray = new
            byte[file.InputStream.Length];
            file.InputStream.Read(binaryWriteArray, 0,
            (int)file.InputStream.Length);
            FileStream objfilestream = new FileStream(Server.MapPath("uploads//" + name), FileMode.Create, FileAccess.ReadWrite);
            objfilestream.Write(binaryWriteArray, 0,
            binaryWriteArray.Length);
            objfilestream.Close();
            string[][] JaggedArray = new string[1][];
            JaggedArray[0] = new string[] { "File was uploaded successfully" };
            JavaScriptSerializer js = new JavaScriptSerializer();
            string strJSON = js.Serialize(JaggedArray);
            return strJSON;
        }
    }
}


